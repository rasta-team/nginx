<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="92bc2f9cd4641b381ee7334feaf3277c90a928e1fa25685e9338bed40e6dd3d3"
DB_SET="mysql:host=localhost;port=3306;dbname=OCSPANEL"
DB_USER="root"
DB_PASS="nawfal94."
?>